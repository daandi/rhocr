#coding: utf-8
require_relative "ocr_page"